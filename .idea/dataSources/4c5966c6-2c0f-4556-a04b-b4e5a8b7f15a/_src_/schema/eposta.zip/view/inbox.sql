CREATE VIEW inbox AS
  SELECT
    `d`.`id`                    AS `id`,
    `d`.`notification_id`       AS `notification_id`,
    `d`.`ebox_id`               AS `ebox_id`,
    `d`.`sent_on_firebase`      AS `sent_on_firebase`,
    `d`.`sent_on_sms`           AS `sent_on_sms`,
    `d`.`date_sent_on_firebase` AS `date_sent_on_firebase`,
    `d`.`date_sent_on_sms`      AS `date_sent_on_sms`,
    `d`.`date_added`            AS `date_added`,
    `d`.`read`                  AS `read`,
    `d`.`date_read`             AS `date_read`,
    `d`.`created_at`            AS `created_at`,
    `d`.`updated_at`            AS `updated_at`,
    `n`.`subject`               AS `subject`,
    `n`.`message`               AS `message`,
    `n`.`sender_ebox_id`        AS `sender_ebox_id`,
    `n`.`send_date`             AS `send_date`,
    `n`.`draft`                 AS `draft`,
    `n`.`data`                  AS `data`,
    `n`.`notification_type_id`  AS `notification_type_id`
  FROM (`eposta`.`dispatch` `d` LEFT JOIN `eposta`.`notifications` `n` ON ((`d`.`id` = `d`.`notification_id`)));
